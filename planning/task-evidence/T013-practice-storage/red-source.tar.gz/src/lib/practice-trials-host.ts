/** RED scaffold; host new publication has not been wired. */
export function practiceTrialWriteConfiguration(): any { throw new Error('NOT_IMPLEMENTED'); }
export async function publishPracticeTrialFromHost(..._args: unknown[]): Promise<any> { throw new Error('NOT_IMPLEMENTED'); }
