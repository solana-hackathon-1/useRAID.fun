/** Genuine RED scaffold; no durable practice definition behavior exists yet. */
export async function publishPracticeTrialDefinition(..._args: unknown[]): Promise<any> {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialDefinition(..._args: unknown[]): Promise<any> {
  throw new Error('NOT_IMPLEMENTED');
}
