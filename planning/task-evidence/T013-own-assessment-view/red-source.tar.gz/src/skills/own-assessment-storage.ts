import type { CommandReceiptTransaction } from '../command-receipts';
import type { SkillTaxonomyActor } from './taxonomy-storage-contracts';
/** TDD placeholder before actual owned projection. */
export async function readOwnSkillAssessment(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _input: unknown,
  _canRead: unknown,
): Promise<never> {
  throw Object.assign(new Error('STORAGE_UNAVAILABLE'), { code: 'STORAGE_UNAVAILABLE' });
}
