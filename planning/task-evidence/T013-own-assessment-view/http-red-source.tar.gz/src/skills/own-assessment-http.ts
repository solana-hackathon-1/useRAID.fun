/** TDD placeholder before authorized private transport. */
export class OwnSkillAssessmentHttpError extends Error {
  constructor(readonly status: 401 | 403 | 429) {
    super('HTTP_AUTHORITY_DENIED');
  }
}
export function createOwnSkillAssessmentHandlers(_host: unknown) {
  return {
    GET: async (_request: Request, _id: string | Promise<string>) =>
      Response.json({}, { status: 503 }),
  };
}
