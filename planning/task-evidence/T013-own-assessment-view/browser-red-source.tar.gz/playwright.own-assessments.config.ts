import { defineConfig, devices } from '@playwright/test';
import { assertTestDatabase } from './tests/helpers/db-guard';
assertTestDatabase();
const baseURL = process.env.OWN_ASSESSMENT_BROWSER_URL || 'http://127.0.0.1:3025';
if (!['127.0.0.1', 'localhost'].includes(new URL(baseURL).hostname))
  throw Error('Owned loopback preview required');
export default defineConfig({
  testDir: './tests/browser-own-assessments',
  testMatch: 'own-assessments.spec.ts',
  workers: 1,
  fullyParallel: false,
  retries: 0,
  timeout: 45000,
  outputDir: 'test-results/own-assessments',
  use: {
    baseURL,
    trace: 'off',
    launchOptions: { executablePath: process.env.OWN_ASSESSMENT_CHROMIUM_EXECUTABLE_PATH },
  },
  projects: [
    { name: 'desktop', use: { ...devices['Desktop Chrome'] } },
    { name: 'mobile', use: { ...devices['iPhone 13'], defaultBrowserType: 'chromium' } },
  ],
});
