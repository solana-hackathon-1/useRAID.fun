import type { SkillTaxonomyActor } from './taxonomy-storage-contracts';
export class PracticeReviewHttpError extends Error {
  constructor(readonly status: 401 | 403 | 429) { super('HTTP_AUTHORITY_DENIED'); }
}
export interface PracticeReviewHttpHost {
  readonly version: 'v1';
  requestId(): string;
  actor(): Promise<SkillTaxonomyActor>;
  rateLimit(actor: SkillTaxonomyActor): void | Promise<void>;
  read(actor: SkillTaxonomyActor, input: unknown): Promise<unknown>;
}
export function createPracticeReviewHandlers(_host: PracticeReviewHttpHost) {
  return { async GET(_request: Request, _params: unknown) { return new Response(null, { status: 503 }); } };
}
