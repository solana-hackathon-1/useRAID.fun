/** RED scaffold: authorized assessment preparation has not been implemented. */
export function prepareSkillAssessmentReview(..._args: unknown[]): any {
  throw new Error('NOT_IMPLEMENTED');
}
export function prepareSkillAssessmentReassessment(..._args: unknown[]): any {
  throw new Error('NOT_IMPLEMENTED');
}
