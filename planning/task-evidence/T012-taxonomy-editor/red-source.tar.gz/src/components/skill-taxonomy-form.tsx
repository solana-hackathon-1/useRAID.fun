'use client';
import type { PublishedSkillTaxonomy } from '../skills/contracts';
export interface SkillTaxonomyEditorState {
  version: 'v1'; taxonomyId: string; publisherAccountId: string;
  taxonomy: PublishedSkillTaxonomy | null; writesAvailable: boolean; unavailableReason: 'DISABLED' | null;
}
export function SkillTaxonomyForm(_props: { state: SkillTaxonomyEditorState }) {
  return <p>Editor not implemented.</p>;
}
