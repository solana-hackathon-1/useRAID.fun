import type { PublishPracticeReviewPolicyCommand } from '../skills/practice-review-policy-storage';
import type { SkillTaxonomyActor } from '../skills/taxonomy-storage';
export function practiceReviewPolicyWriteConfiguration(): {
  writesAvailable: boolean;
  unavailableReason: 'DISABLED' | null;
} {
  return { writesAvailable: true, unavailableReason: null };
}
export async function publishPracticeReviewPolicyFromHost(
  _command: PublishPracticeReviewPolicyCommand,
) {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeReviewPolicyAsAdminFromHost(
  _actor: SkillTaxonomyActor,
  _id: string,
  _revision?: number,
) {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readApprovedPracticeReviewPolicyFromHost(
  _actor: SkillTaxonomyActor,
  _input: unknown,
) {
  throw new Error('NOT_IMPLEMENTED');
}
