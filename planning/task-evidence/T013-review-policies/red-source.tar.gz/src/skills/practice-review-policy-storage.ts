import type { CommandReceiptTransaction } from '../command-receipts';
import type { SkillTaxonomyActor } from './taxonomy-storage';
export interface PracticeReviewPolicyScope {
  readonly accountId: string;
  readonly xId: string;
  readonly policyId: string;
  readonly definitionReference: Readonly<{ recordId: string; revision: number }>;
  readonly rubricReference: Readonly<{ recordId: string; revision: number }>;
  readonly skillId: string;
  readonly skillDomain: string;
  readonly targetRank: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
}
export interface PracticeReviewPolicyUseScope {
  readonly actorAccountId: string;
  readonly assignmentId: string;
  readonly submissionId: string;
  readonly policyReference: Readonly<{ recordId: string; revision: number }>;
  readonly policyVersionId: string;
  readonly definitionReference: Readonly<{ recordId: string; revision: number }>;
  readonly skillId: string;
  readonly skillDomain: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
}
export interface PracticeReviewPolicyOptions {
  readonly allowNewWrites: boolean;
  readonly canPublish: (scope: PracticeReviewPolicyScope) => boolean;
}
export interface PublishPracticeReviewPolicyCommand {
  readonly actor: SkillTaxonomyActor;
  readonly input: unknown;
  readonly idempotencyKey: string;
  readonly requestId: string;
}
export interface PracticeReviewPolicyRecord {
  readonly version: 'v1';
  readonly id: string;
  readonly reference: Readonly<{ recordId: string; revision: number }>;
  readonly definitionReference: Readonly<{ recordId: string; revision: number }>;
  readonly rubricReference: Readonly<{ recordId: string; revision: number }>;
  readonly skillId: string;
  readonly skillDomain: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
  readonly state: 'APPROVED' | 'WITHDRAWN';
  readonly guidance: string;
  readonly publishedByAccountId: string;
  readonly publishedAt: string;
  readonly persisted: true;
  readonly verifiesSkill: false;
  readonly confirmsOwnership: false;
  readonly createsPermissionGrant: false;
  readonly isAuthorizationToken: false;
  readonly consumesCapacity: false;
  readonly createsFinancialObligation: false;
}
export interface PracticeReviewPolicyView {
  readonly version: 'v1';
  readonly private: true;
  readonly policy: PracticeReviewPolicyRecord;
  readonly accessId: string;
  readonly isAuthorizationToken: false;
}
export class PracticeReviewPolicyError extends Error {
  constructor(readonly code: string) {
    super(code);
    this.name = 'PracticeReviewPolicyError';
  }
}
export async function publishPracticeReviewPolicy(
  _tx: CommandReceiptTransaction,
  _command: PublishPracticeReviewPolicyCommand,
  _options: PracticeReviewPolicyOptions,
): Promise<{
  status: 'EXECUTED' | 'REPLAYED';
  policy: PracticeReviewPolicyRecord;
  accessId: string;
}> {
  throw new PracticeReviewPolicyError('STORAGE_UNAVAILABLE');
}
export async function readPracticeReviewPolicyAsAdmin(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _policyId: string,
  _revision: number | undefined,
  _canPublish: PracticeReviewPolicyOptions['canPublish'],
): Promise<PracticeReviewPolicyView | null> {
  throw new PracticeReviewPolicyError('STORAGE_UNAVAILABLE');
}
export async function lockApprovedPracticeReviewPolicy(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _input: unknown,
  _canUse: (scope: PracticeReviewPolicyUseScope) => boolean,
): Promise<PracticeReviewPolicyView | null> {
  throw new PracticeReviewPolicyError('STORAGE_UNAVAILABLE');
}
