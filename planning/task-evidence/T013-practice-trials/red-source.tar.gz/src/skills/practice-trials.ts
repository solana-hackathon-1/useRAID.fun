/** Typed RED scaffold; no approved practice-trial behavior exists yet. */
export function readPracticeTrial(..._args: unknown[]): any {
  throw new Error('NOT_IMPLEMENTED');
}
export function preparePracticeTrialAttempt(..._args: unknown[]): any {
  throw new Error('NOT_IMPLEMENTED');
}
