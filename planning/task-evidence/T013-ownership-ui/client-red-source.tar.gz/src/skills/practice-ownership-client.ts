export function createOwnershipEditor(_context: unknown,_write: unknown,_key:unknown) {
 return {save:async(_fields:unknown)=>{},retry:async()=>{},snapshot:()=>({phase:'UNAVAILABLE',context:null,message:''}),subscribe:(_listener:unknown)=>()=>{}};
}
