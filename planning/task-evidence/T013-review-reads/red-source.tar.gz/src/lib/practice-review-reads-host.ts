import type { SkillTaxonomyActor } from '../skills/taxonomy-storage';
export function practiceReviewReadConfiguration(): {
  readsAvailable: boolean;
  unavailableReason: 'DISABLED' | null;
} {
  return { readsAvailable: true, unavailableReason: null };
}
export async function readPracticeTrialForReviewFromHost(
  _actor: SkillTaxonomyActor,
  _input: unknown,
) {
  throw new Error('NOT_IMPLEMENTED');
}
