import type { CommandReceiptTransaction } from '../command-receipts';
import type { SkillTaxonomyActor } from './taxonomy-storage';
import type { PracticeTrialDefinition } from './practice-trial-contracts';
import type { PracticeTrialSubmissionRecord } from './practice-trial-submission-storage';
import type {
  PracticeReviewAssignmentRecord,
  PracticeReviewAssignmentUseScope,
} from './practice-review-assignment-storage';
export interface ReadPracticeReviewInput {
  readonly version: 'v1';
  readonly assignmentId: string;
  readonly submissionId: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
}
export interface PracticeReviewReadRecord {
  readonly version: 'v1';
  readonly private: true;
  readonly assignment: PracticeReviewAssignmentRecord;
  readonly definition: PracticeTrialDefinition;
  readonly submission: PracticeTrialSubmissionRecord;
  readonly isAuthorizationToken: false;
}
export class PracticeReviewReadError extends Error {
  constructor(readonly code: string) {
    super(code);
    this.name = 'PracticeReviewReadError';
  }
}
export async function readPracticeTrialForReview(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _input: unknown,
  _canRead: (scope: PracticeReviewAssignmentUseScope) => boolean,
): Promise<PracticeReviewReadRecord | null> {
  throw new PracticeReviewReadError('STORAGE_UNAVAILABLE');
}
