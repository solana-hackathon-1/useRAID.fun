import type { PublishSkillTaxonomyCommand } from '../skills/taxonomy-storage';
export function skillTaxonomyWriteConfiguration() {
  return { writesAvailable: false, unavailableReason: 'DISABLED' as 'DISABLED' | null };
}
export async function publishSkillTaxonomyFromHost(_command: PublishSkillTaxonomyCommand): Promise<unknown> {
  throw new Error('NOT_IMPLEMENTED');
}
