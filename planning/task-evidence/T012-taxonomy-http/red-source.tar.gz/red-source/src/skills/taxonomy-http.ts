import type { PublishSkillTaxonomyCommand, SkillTaxonomyActor } from './taxonomy-storage-contracts';
export interface SkillTaxonomyHttpHost {
  readonly version: 'v1';
  actor(): Promise<SkillTaxonomyActor>;
  checkOrigin(request: Request): void | Promise<void>;
  rateLimit(actor: SkillTaxonomyActor): Promise<void>;
  publish(command: PublishSkillTaxonomyCommand): Promise<unknown>;
  requestId(): string;
}
export class SkillTaxonomyHttpError extends Error {
  constructor(readonly status: 401 | 403 | 429) {
    super('HTTP_AUTHORITY_DENIED');
  }
}
export function createSkillTaxonomyHandlers(_host: SkillTaxonomyHttpHost) {
  return { async POST(_request: Request, _id: string | Promise<string>) {
    return Response.json({ error: { code: 'SERVICE_UNAVAILABLE' } }, { status: 503 });
  } };
}
