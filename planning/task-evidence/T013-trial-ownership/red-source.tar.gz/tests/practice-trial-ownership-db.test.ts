import { randomUUID } from 'node:crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { db } from '../src/lib/db';
import { hash } from '../src/lib/auth-primitives';
import { runCommandTransaction } from '../src/lib/command-receipts-adapter';
import { executeIdempotentCommand, type CommandReceiptTransaction } from '../src/command-receipts';
import { publishSkillTaxonomy, type SkillTaxonomyActor } from '../src/skills/taxonomy-storage';
import { publishPracticeTrialDefinition } from '../src/skills/practice-trial-storage';
import { startPracticeTrial } from '../src/skills/practice-trial-attempt-storage';
import { submitPracticeTrial } from '../src/skills/practice-trial-submission-storage';
import {
  issuePracticeReviewAssignment,
  revokePracticeReviewAssignment,
  lockPracticeReviewAssignment,
  type PracticeReviewAssignmentOptions,
} from '../src/skills/practice-review-assignment-storage';
import { definition as fixture } from '../examples/skill-assessments/fixtures';
import { assertTestDatabase, truncateAll } from './helpers/db-guard';
const integration = process.env.RUN_DB_TESTS === 'true' ? describe : describe.skip;
const catalogId = 'synthetic-submission-catalog',
  trialId = 'synthetic-submission-trial';
let publisher: SkillTaxonomyActor,
  subject: SkillTaxonomyActor,
  startId: string,
  participantId: string;
const skills = [
  { id: 'frontend', domain: 'web', name: 'Frontend', status: 'ACTIVE', aliases: ['frontend'] },
];
async function actor(admin = false, mapped = true) {
  const user = await db.user.create({
    data: {
      handle: 'synthetic',
      role: admin ? 'ADMIN' : 'CREATOR',
      xId: admin ? randomUUID() : null,
    },
  });
  const sessionHash = hash(randomUUID());
  await db.session.create({
    data: {
      tokenHash: sessionHash,
      userId: user.id,
      via: admin ? 'x' : 'wallet',
      expiresAt: new Date(Date.now() + 60000),
    },
  });
  if (mapped)
    await db.participant.create({
      data: {
        accountId: user.id,
        provisionActorAccountId: user.id,
        provisionRequestId: 'synthetic-provision',
      },
    });
  return { accountId: user.id, sessionHash };
}
const publishCatalog = (revision = 0, entries: unknown = skills) =>
  runCommandTransaction(db, (tx) =>
    publishSkillTaxonomy(
      tx,
      {
        actor: publisher,
        input: { taxonomyId: catalogId, expectedRevision: revision, skills: entries },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-catalog',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
function definitionInput(revision = 0, availability = 'AVAILABLE') {
  const draft = structuredClone(fixture);
  for (const field of ['reference', 'publishedAt', 'state']) Reflect.deleteProperty(draft, field);
  return {
    trialId,
    expectedRevision: revision,
    taxonomyReference: { recordId: catalogId, revision: 1 },
    availability,
    draft: {
      ...draft,
      maximumAttempts: 3,
      cooldownSeconds: 0,
      rubric: {
        ...draft.rubric,
        reference: { recordId: 'synthetic-submission-rubric', revision: 1 },
      },
    },
  };
}
const publish = (revision = 0, availability = 'AVAILABLE') =>
  runCommandTransaction(db, (tx) =>
    publishPracticeTrialDefinition(
      tx,
      {
        actor: publisher,
        input: definitionInput(revision, availability),
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-definition',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
const begin = (a = subject) =>
  runCommandTransaction(db, (tx) =>
    startPracticeTrial(
      tx,
      {
        actor: a,
        input: {
          version: 'v1',
          definitionReference: { recordId: trialId, revision: 1 },
          accommodationReference: null,
        },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-start',
      },
      { allowNewWrites: true },
    ),
  );
function input() {
  return {
    version: 'v1',
    startId,
    expectedDefinitionReference: { recordId: trialId, revision: 1 },
    expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
    answer: '\n  const answer = "<script>literal</script>";\r\n',
    explanation: 'I can explain and modify this invented solution.',
    toolsUsed: ['editor'],
    aiAssistanceUsed: false,
    assistanceDisclosure: 'No AI assistance declared.',
  };
}
const submit = (a = subject, body: unknown = input(), key = randomUUID(), enabled = true) =>
  runCommandTransaction(db, (tx) =>
    submitPracticeTrial(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-submit' },
      { allowNewWrites: enabled },
    ),
  );

let evaluator: SkillTaxonomyActor, submissionId: string;
const policy: PracticeReviewAssignmentOptions = {
  allowNewWrites: true,
  canManage: (s) =>
    s.issuerAccountId === publisher.accountId &&
    s.evaluatorAccountId === evaluator.accountId &&
    s.subjectAccountId === subject.accountId &&
    s.participantId === participantId &&
    s.skillId === 'frontend',
};
const grantInput = () => ({
  version: 'v1',
  submissionId,
  evaluatorAccountId: evaluator.accountId,
  purpose: 'OWNERSHIP_REVIEW',
  expiresAt: new Date(Date.now() + 60000).toISOString(),
  reason: 'Synthetic bounded ownership review.',
});
const issue = (body: unknown = grantInput(), a = publisher, opts = policy, key = randomUUID()) =>
  runCommandTransaction(db, (tx) =>
    issuePracticeReviewAssignment(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-issue' },
      opts,
    ),
  );
const revoke = (
  id: string,
  a = publisher,
  opts = policy,
  key = randomUUID(),
  reason = 'Synthetic case access revoked.',
) =>
  runCommandTransaction(db, (tx) =>
    revokePracticeReviewAssignment(
      tx,
      {
        actor: a,
        input: { version: 'v1', assignmentId: id, reason },
        idempotencyKey: key,
        requestId: 'synthetic-revoke',
      },
      opts,
    ),
  );
const use = (
  id: string,
  a = evaluator,
  sub = submissionId,
  purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW' = 'OWNERSHIP_REVIEW',
  canUse: Parameters<typeof lockPracticeReviewAssignment>[3] = () => true,
) =>
  runCommandTransaction(db, (tx) =>
    lockPracticeReviewAssignment(tx, a, { assignmentId: id, submissionId: sub, purpose }, canUse),
  );

import {
  publishPracticeReviewPolicy,
  observeApprovedPracticeReviewPolicy,
  readPracticeReviewPolicyAsAdmin,
  lockApprovedPracticeReviewPolicy,
  type PracticeReviewPolicyOptions,
} from '../src/skills/practice-review-policy-storage';
const policyId = 'synthetic-ownership-policy';
let assignmentId: string;
const policyInput = () => ({
  version: 'v1',
  policyId,
  expectedRevision: 0,
  definitionReference: { recordId: trialId, revision: 1 },
  purpose: 'OWNERSHIP_REVIEW',
  state: 'APPROVED',
  guidance:
    'Synthetic manual review guidance; original accepted rubric/tool rules remain authoritative.',
});
const publicationOptions: PracticeReviewPolicyOptions = {
  allowNewWrites: true,
  canPublish: (scope) =>
    scope.accountId === publisher.accountId &&
    scope.definitionReference.recordId === trialId &&
    scope.skillId === 'frontend',
};
const publishPolicy = (
  body: unknown = policyInput(),
  a = publisher,
  options = publicationOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    publishPracticeReviewPolicy(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-policy' },
      options,
    ),
  );
const adminRead = (
  id = policyId,
  revision: number | undefined = undefined,
  a = publisher,
  canPublish = publicationOptions.canPublish,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeReviewPolicyAsAdmin(tx, a, id, revision, canPublish),
  );
const policyLookupInput = () => ({
  version: 'v1',
  assignmentId,
  submissionId,
  purpose: 'OWNERSHIP_REVIEW',
  expectedPolicyReference: { recordId: policyId, revision: 1 },
});
const lookupPolicy = (
  body: unknown = policyLookupInput(),
  a = evaluator,
  canUse: Parameters<typeof lockApprovedPracticeReviewPolicy>[3] = () => true,
) => runCommandTransaction(db, (tx) => lockApprovedPracticeReviewPolicy(tx, a, body, canUse));
import {
  recordPracticeTrialOwnership,
  readPracticeTrialOwnership,
} from '../src/skills/practice-trial-ownership-storage';
const ownershipInput = () => ({
  version: 'v1',
  assignmentId,
  submissionId,
  expectedSubmissionReference: { recordId: submissionId, revision: 1 },
  expectedDefinitionReference: { recordId: trialId, revision: 1 },
  expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
  expectedPolicyReference: { recordId: policyId, revision: 1 },
  expectedOwnershipReference: null,
  decision: 'CONFIRM',
  reason: 'Synthetic evaluator observed explanation and modification under original rules.',
  observations: [
    {
      kind: 'EXPLANATION',
      detail: 'Synthetic explanation reviewed against saved original solution.',
    },
    { kind: 'MODIFICATION', detail: 'Synthetic bounded modification observed.' },
  ],
});
const ownershipOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canReview: () => true,
};
const recordOwnership = (
  body: unknown = ownershipInput(),
  a = evaluator,
  options = ownershipOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeTrialOwnership(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-ownership' },
      options,
    ),
  );
const readOwnership = (
  revision: number | undefined = undefined,
  a = evaluator,
  id = assignmentId,
  purpose = 'OWNERSHIP_REVIEW',
  canRead = ownershipOptions.canRead,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeTrialOwnership(
      tx,
      a,
      { version: 'v1', assignmentId: id, submissionId, purpose, revision },
      canRead,
    ),
  );
integration('T013D4 actual immutable trial ownership findings', () => {
  beforeAll(() => assertTestDatabase());
  beforeEach(async () => {
    await truncateAll(db);
    publisher = await actor(true, false);
    subject = await actor();
    evaluator = await actor(false, false);
    await publishCatalog();
    await publish();
    const s = await begin();
    startId = s.start.id;
    participantId = s.start.participantId;
    submissionId = (await submit()).submission.reference.recordId;
    assignmentId = (await issue()).assignment.id;
    await publishPolicy();
  });
  afterAll(() => db.$disconnect());
  it('commits actual attributed canonical finding with private access provenance and no rank/grant/money or original declaration mutation', async () => {
    const r = await recordOwnership();
    expect(r.status).toBe('EXECUTED');
    expect(r.view.record).toMatchObject({
      reference: { recordId: submissionId, revision: 1 },
      submissionReference: { recordId: submissionId, revision: 1 },
      definitionReference: { recordId: trialId, revision: 1 },
      rubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
      policyReference: { recordId: policyId, revision: 1 },
      assignmentId,
      evaluatorAccountId: evaluator.accountId,
      decision: 'CONFIRM',
      ownership: 'CONFIRMED',
      persisted: true,
      verifiesSkill: false,
      isAuthorizationToken: false,
      createsPermissionGrant: false,
      consumesCapacity: false,
      createsFinancialObligation: false,
    });
    expect(r.view.isCurrent).toBe(true);
    expect(r.view.record.caseAccessId).toMatch(/^[0-9a-f-]{36}$/);
    expect(r.view.record.policyAccessId).toMatch(/^[0-9a-f-]{36}$/);
    expect((await submit(subject, input(), randomUUID())).submission.ownership).toBe('UNCONFIRMED');
    expect(await db.outboxEvent.count()).toBe(0);
  });
  it('has no current finding before a decision rather than confirming a claimant declaration', async () => {
    expect(await readOwnership()).toBeNull();
  });
  it('appends correction preserving original private history and explicit current pointer', async () => {
    const first = await recordOwnership();
    const second = await recordOwnership({
      ...ownershipInput(),
      expectedOwnershipReference: first.view.record.reference,
      decision: 'DISPUTE',
      reason: 'Synthetic correction requests evidence; no fraud conviction.',
    });
    expect(second.view.record).toMatchObject({
      reference: { recordId: submissionId, revision: 2 },
      ownership: 'DISPUTED',
    });
    expect((await readOwnership(1))?.isCurrent).toBe(false);
    expect((await readOwnership())?.record).toEqual(second.view.record);
  });
  it('records more evidence as UNCONFIRMED without automatic rank or culpability', async () => {
    expect(
      (await recordOwnership({ ...ownershipInput(), decision: 'MORE_EVIDENCE' })).view.record
        .ownership,
    ).toBe('UNCONFIRMED');
  });
  it('replays original unknown-success result after correction/writeoff/policywithdrawal under current read permission', async () => {
    const key = randomUUID(),
      body = ownershipInput(),
      first = await recordOwnership(body, evaluator, ownershipOptions, key);
    await recordOwnership({
      ...body,
      expectedOwnershipReference: first.view.record.reference,
      decision: 'MORE_EVIDENCE',
    });
    await publishPolicy({ ...policyInput(), expectedRevision: 1, state: 'WITHDRAWN' });
    const replay = await recordOwnership(
      body,
      evaluator,
      {
        ...ownershipOptions,
        allowNewWrites: false,
        canUsePolicy: () => false,
        canReview: () => false,
      },
      key,
    );
    expect(replay.status).toBe('REPLAYED');
    expect(replay.view.record).toEqual(first.view.record);
    expect(replay.view.isCurrent).toBe(false);
    expect(replay.view.accessId).not.toBe(first.view.accessId);
  });
  it('rejects changed body on the same idempotency key', async () => {
    const key = randomUUID();
    await recordOwnership(ownershipInput(), evaluator, ownershipOptions, key);
    await expect(
      recordOwnership({ ...ownershipInput(), reason: 'Changed' }, evaluator, ownershipOptions, key),
    ).rejects.toMatchObject({ code: 'IDEMPOTENCY_CONFLICT' });
  });
  it('requires exact CAS and serializes two competing independent decisions', async () => {
    const r = await Promise.allSettled([
      recordOwnership(),
      recordOwnership({ ...ownershipInput(), decision: 'MORE_EVIDENCE' }),
    ]);
    expect(r.filter((x) => x.status === 'fulfilled')).toHaveLength(1);
    expect(r.filter((x) => x.status === 'rejected')).toHaveLength(1);
    expect(r.find((x) => x.status === 'rejected')).toMatchObject({
      reason: { code: 'REVISION_CHANGED' },
    });
  });
  it.each([
    'expectedSubmissionReference',
    'expectedDefinitionReference',
    'expectedRubricReference',
    'expectedPolicyReference',
  ])('denies changed original or current %s', async (field) => {
    await expect(
      recordOwnership({ ...ownershipInput(), [field]: { recordId: 'foreign', revision: 1 } }),
    ).rejects.toMatchObject({ code: 'REVISION_CHANGED' });
  });
  it('requires actual current policy, rejects withdrawn and stale approved history', async () => {
    await publishPolicy({ ...policyInput(), expectedRevision: 1, state: 'WITHDRAWN' });
    await expect(
      recordOwnership({
        ...ownershipInput(),
        expectedPolicyReference: { recordId: policyId, revision: 2 },
      }),
    ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
    await expect(recordOwnership()).rejects.toMatchObject({ code: 'REVISION_CHANGED' });
  });
  it('denies writeoff without leaving a business outcome or command receipt', async () => {
    await expect(
      recordOwnership(ownershipInput(), evaluator, { ...ownershipOptions, allowNewWrites: false }),
    ).rejects.toMatchObject({ code: 'WRITES_DISABLED' });
    expect(
      await db.commandReceipt.count({ where: { commandKind: 'RecordPracticeTrialOwnership' } }),
    ).toBe(0);
  });
  it.each(['canRead', 'canUsePolicy', 'canReview'])(
    'fails closed when current %s denies',
    async (field) => {
      await expect(
        recordOwnership(ownershipInput(), evaluator, { ...ownershipOptions, [field]: () => false }),
      ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
    },
  );
  it('requires exact assigned evaluator rather than admin role or claimant', async () => {
    await expect(recordOwnership(ownershipInput(), publisher)).rejects.toMatchObject({
      code: 'RESOURCE_UNAVAILABLE',
    });
    await expect(recordOwnership(ownershipInput(), subject)).rejects.toMatchObject({
      code: 'RESOURCE_UNAVAILABLE',
    });
  });
  it('denies lost own session and suspended current evaluator', async () => {
    await db.session.deleteMany({ where: { userId: evaluator.accountId } });
    await expect(recordOwnership()).rejects.toMatchObject({ code: 'AUTHENTICATION_REQUIRED' });
  });
  it('denies assignment revocation for new writes/history/replay', async () => {
    const key = randomUUID();
    await recordOwnership(ownershipInput(), evaluator, ownershipOptions, key);
    await revoke(assignmentId);
    expect(await readOwnership()).toBeNull();
    await expect(
      recordOwnership(ownershipInput(), evaluator, ownershipOptions, key),
    ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
  });
  it('denies expired or wrong-purpose assignment', async () => {
    const a = await issue({ ...grantInput(), purpose: 'ASSESSMENT_REVIEW' });
    await expect(
      recordOwnership({ ...ownershipInput(), assignmentId: a.assignment.id }),
    ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
  });
  it('only exposes historical reason under actual current exact case assignment; assessment reviewers may inspect ownership without gaining ownership write authority', async () => {
    const r = await recordOwnership();
    expect(await readOwnership(undefined, publisher)).toBeNull();
    expect(await readOwnership(undefined, evaluator, assignmentId, 'ASSESSMENT_REVIEW')).toBeNull();
    const a = await issue({ ...grantInput(), purpose: 'ASSESSMENT_REVIEW' });
    expect(
      (await readOwnership(undefined, evaluator, a.assignment.id, 'ASSESSMENT_REVIEW'))?.record,
    ).toEqual(r.view.record);
  });
  it.each(['', 'x'.repeat(2001), '😀'.repeat(1001), 'x\u0000', 'x\ud800'])(
    'rejects malformed or over-UTF16 private reason before queries',
    async (reason) => {
      await expect(recordOwnership({ ...ownershipInput(), reason })).rejects.toMatchObject({
        code: 'INVALID_INPUT',
      });
    },
  );
  it('preserves literal SQL/HTML shaped reviewer observations without executing them', async () => {
    const reason = '<script>literal</script>\'; DROP TABLE "User";--';
    expect((await recordOwnership({ ...ownershipInput(), reason })).view.record.reason).toBe(
      reason,
    );
    expect(await db.user.count()).toBe(3);
  });
});
