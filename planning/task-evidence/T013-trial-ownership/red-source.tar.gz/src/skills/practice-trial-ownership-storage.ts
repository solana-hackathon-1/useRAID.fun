// Typed RED placeholders; no ownership implementation exists yet.
export async function recordPracticeTrialOwnership(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialOwnership(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
