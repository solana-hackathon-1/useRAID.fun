// Typed RED placeholders before Root composition.
export function practiceTrialOwnershipWriteConfiguration(): unknown {
  return undefined;
}
export async function recordPracticeTrialOwnershipFromHost(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialOwnershipFromHost(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
