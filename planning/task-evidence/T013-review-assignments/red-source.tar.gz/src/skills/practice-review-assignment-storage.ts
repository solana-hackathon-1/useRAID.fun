import type { CommandReceiptTransaction } from '../command-receipts';
import type { SkillTaxonomyActor } from './taxonomy-storage';
export class PracticeReviewAssignmentError extends Error {
  constructor(readonly code: string) {
    super(code);
    this.name = 'PracticeReviewAssignmentError';
  }
}
export interface PracticeReviewAssignmentScope {
  readonly issuerAccountId: string;
  readonly xId: string;
  readonly submissionId: string;
  readonly subjectAccountId: string;
  readonly participantId: string;
  readonly evaluatorAccountId: string;
  readonly skillId: string;
  readonly skillDomain: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
}
export interface PracticeReviewAssignmentOptions {
  readonly allowNewWrites: boolean;
  readonly canManage: (scope: PracticeReviewAssignmentScope) => boolean;
}
export interface PracticeReviewAssignmentCommand {
  readonly actor: SkillTaxonomyActor;
  readonly input: unknown;
  readonly idempotencyKey: string;
  readonly requestId: string;
}
export interface PracticeReviewAssignmentRecord {
  readonly id: string;
  readonly submissionId: string;
  readonly evaluatorAccountId: string;
  readonly purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
  readonly expiresAt: string;
  readonly issuedAt: string;
  readonly issuedByAccountId: string;
  readonly reason: string;
  readonly version: 'v1';
  readonly state: 'ISSUED';
  readonly isAuthorizationToken: false;
}
export async function issuePracticeReviewAssignment(
  _tx: CommandReceiptTransaction,
  _command: PracticeReviewAssignmentCommand,
  _options: PracticeReviewAssignmentOptions,
): Promise<{ status: 'EXECUTED' | 'REPLAYED'; assignment: PracticeReviewAssignmentRecord }> {
  throw new PracticeReviewAssignmentError('STORAGE_UNAVAILABLE');
}
export async function revokePracticeReviewAssignment(
  _tx: CommandReceiptTransaction,
  _command: PracticeReviewAssignmentCommand,
  _options: PracticeReviewAssignmentOptions,
): Promise<{
  status: 'EXECUTED' | 'REPLAYED';
  revocation: { id: string; assignmentId: string; reason: string };
}> {
  throw new PracticeReviewAssignmentError('STORAGE_UNAVAILABLE');
}
export async function lockPracticeReviewAssignment(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _scope: {
    assignmentId: string;
    submissionId: string;
    purpose: 'OWNERSHIP_REVIEW' | 'ASSESSMENT_REVIEW';
  },
  _canUse: (scope: PracticeReviewAssignmentScope) => boolean,
): Promise<PracticeReviewAssignmentRecord | null> {
  throw new PracticeReviewAssignmentError('STORAGE_UNAVAILABLE');
}
