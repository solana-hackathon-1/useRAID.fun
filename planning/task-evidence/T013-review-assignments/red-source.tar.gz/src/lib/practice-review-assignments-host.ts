import type { PracticeReviewAssignmentCommand } from '../skills/practice-review-assignment-storage';
export function practiceReviewAssignmentWriteConfiguration(): {writesAvailable:boolean;unavailableReason:'DISABLED'|null} {return {writesAvailable:true,unavailableReason:null};}
export async function issuePracticeReviewAssignmentFromHost(_command:PracticeReviewAssignmentCommand) {throw new Error('NOT_IMPLEMENTED');}
export async function revokePracticeReviewAssignmentFromHost(_command:PracticeReviewAssignmentCommand) {throw new Error('NOT_IMPLEMENTED');}
