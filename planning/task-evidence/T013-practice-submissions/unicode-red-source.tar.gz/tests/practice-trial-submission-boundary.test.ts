import { expect, it } from 'vitest';
import { EventEnvelopeSchema } from '../src/contracts/protocol';
it('accepts only an opaque private submission audit reference', () => {
  const event = {
    eventId: 'e',
    type: 'skill.practice_trial_submitted.v1',
    aggregateId: 'submission',
    aggregateVersion: 1,
    occurredAt: '2026-10-15T00:00:00Z',
    actorId: 'actor',
    guildId: null,
    correlationId: 'r',
    payload: { practiceTrialSubmissionId: 'submission' },
  };
  expect(EventEnvelopeSchema.safeParse(event).success).toBe(true);
  for (const field of ['answer', 'explanation', 'ownership', 'assessedRank'])
    expect(
      EventEnvelopeSchema.safeParse({ ...event, payload: { ...event.payload, [field]: 'private' } })
        .success,
    ).toBe(false);
});
import { randomUUID } from 'node:crypto';
import { SubmitPracticeTrialInputSchema } from '../src/skills/practice-trial-submission-storage';
const body = {
  version: 'v1',
  startId: randomUUID(),
  expectedDefinitionReference: { recordId: 'trial', revision: 1 },
  expectedRubricReference: { recordId: 'rubric', revision: 1 },
  answer: 'Synthetic response.',
  explanation: 'Synthetic explanation.',
  toolsUsed: ['editor'],
  aiAssistanceUsed: false,
  assistanceDisclosure: 'None declared.',
};
it.each([
  ['answer', { answer: '😀'.repeat(20001) }],
  ['explanation', { explanation: '😀'.repeat(2001) }],
  ['assistanceDisclosure', { assistanceDisclosure: '😀'.repeat(2001) }],
  ['toolsUsed', { toolsUsed: ['😀'.repeat(101)] }],
])('bounds %s using the declared UTF16 storage units', (_name, patch) => {
  expect(SubmitPracticeTrialInputSchema.safeParse({ ...body, ...patch }).success).toBe(false);
});
