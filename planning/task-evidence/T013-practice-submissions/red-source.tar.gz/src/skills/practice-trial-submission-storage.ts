import { z } from 'zod';
import type { SkillTaxonomyActor } from './taxonomy-storage';
import type { CommandReceiptTransaction } from '../command-receipts';
export const PracticeTrialSubmissionRecordSchema = z.never();
export class PracticeTrialSubmissionStorageError extends Error {
  constructor(readonly code: string) {
    super(code);
  }
}
export type PracticeTrialSubmissionRecord = Readonly<{
  reference: { recordId: string; revision: number };
  participantId: string;
  answer: string;
  ownership: 'UNCONFIRMED';
}>;
export async function submitPracticeTrial(
  _tx: CommandReceiptTransaction,
  _command: {
    actor: SkillTaxonomyActor;
    input: unknown;
    idempotencyKey: string;
    requestId: string;
  },
  _options: { allowNewWrites: boolean },
): Promise<{ status: 'EXECUTED' | 'REPLAYED'; submission: PracticeTrialSubmissionRecord }> {
  throw Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialSubmission(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _id: string,
): Promise<PracticeTrialSubmissionRecord | null> {
  throw Error('NOT_IMPLEMENTED');
}
