import { expect, it } from 'vitest';
import { EventEnvelopeSchema } from '../src/contracts/protocol';
it('accepts only an opaque private submission audit reference', () => {
  const event = {
    eventId: 'e',
    type: 'skill.practice_trial_submitted.v1',
    aggregateId: 'submission',
    aggregateVersion: 1,
    occurredAt: '2026-10-15T00:00:00Z',
    actorId: 'actor',
    guildId: null,
    correlationId: 'r',
    payload: { practiceTrialSubmissionId: 'submission' },
  };
  expect(EventEnvelopeSchema.safeParse(event).success).toBe(true);
  for (const field of ['answer', 'explanation', 'ownership', 'assessedRank'])
    expect(
      EventEnvelopeSchema.safeParse({ ...event, payload: { ...event.payload, [field]: 'private' } })
        .success,
    ).toBe(false);
});
