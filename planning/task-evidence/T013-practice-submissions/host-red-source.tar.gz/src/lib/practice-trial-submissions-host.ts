import type { SkillTaxonomyActor } from '../skills/taxonomy-storage';
export function practiceTrialSubmissionWriteConfiguration():{writesAvailable:boolean;unavailableReason:'DISABLED'|null}{throw Error('NOT_IMPLEMENTED');}
export async function submitPracticeTrialFromHost(_command:{actor:SkillTaxonomyActor;input:unknown;idempotencyKey:string;requestId:string}):Promise<unknown>{throw Error('NOT_IMPLEMENTED');}
