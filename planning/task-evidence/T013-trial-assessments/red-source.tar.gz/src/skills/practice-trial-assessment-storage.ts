// Typed RED placeholders; no actual assessment persistence exists yet.
export async function recordPracticeTrialAssessment(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialAssessment(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
