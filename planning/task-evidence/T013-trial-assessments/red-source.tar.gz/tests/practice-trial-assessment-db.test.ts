import { readPracticeTrialForReview } from '../src/skills/practice-review-read-storage';
import { randomUUID } from 'node:crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { db } from '../src/lib/db';
import { hash } from '../src/lib/auth-primitives';
import { runCommandTransaction } from '../src/lib/command-receipts-adapter';
import { executeIdempotentCommand } from '../src/command-receipts';
import { publishSkillTaxonomy, type SkillTaxonomyActor } from '../src/skills/taxonomy-storage';
import { publishPracticeTrialDefinition } from '../src/skills/practice-trial-storage';
import { startPracticeTrial } from '../src/skills/practice-trial-attempt-storage';
import {
  submitPracticeTrial,
  readPracticeTrialSubmission,
} from '../src/skills/practice-trial-submission-storage';
import {
  issuePracticeReviewAssignment,
  revokePracticeReviewAssignment,
  type PracticeReviewAssignmentOptions,
} from '../src/skills/practice-review-assignment-storage';
import { definition as fixture } from '../examples/skill-assessments/fixtures';
import { assertTestDatabase, truncateAll } from './helpers/db-guard';
const integration = process.env.RUN_DB_TESTS === 'true' ? describe : describe.skip;
const catalogId = 'synthetic-submission-catalog',
  trialId = 'synthetic-submission-trial';
let publisher: SkillTaxonomyActor,
  subject: SkillTaxonomyActor,
  startId: string,
  participantId: string;
const skills = [
  { id: 'frontend', domain: 'web', name: 'Frontend', status: 'ACTIVE', aliases: ['frontend'] },
];
async function actor(admin = false, mapped = true) {
  const user = await db.user.create({
    data: {
      handle: 'synthetic',
      role: admin ? 'ADMIN' : 'CREATOR',
      xId: admin ? randomUUID() : null,
    },
  });
  const sessionHash = hash(randomUUID());
  await db.session.create({
    data: {
      tokenHash: sessionHash,
      userId: user.id,
      via: admin ? 'x' : 'wallet',
      expiresAt: new Date(Date.now() + 60000),
    },
  });
  if (mapped)
    await db.participant.create({
      data: {
        accountId: user.id,
        provisionActorAccountId: user.id,
        provisionRequestId: 'synthetic-provision',
      },
    });
  return { accountId: user.id, sessionHash };
}
const publishCatalog = (revision = 0, entries: unknown = skills) =>
  runCommandTransaction(db, (tx) =>
    publishSkillTaxonomy(
      tx,
      {
        actor: publisher,
        input: { taxonomyId: catalogId, expectedRevision: revision, skills: entries },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-catalog',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
function definitionInput(revision = 0, availability = 'AVAILABLE') {
  const draft = structuredClone(fixture);
  for (const field of ['reference', 'publishedAt', 'state']) Reflect.deleteProperty(draft, field);
  return {
    trialId,
    expectedRevision: revision,
    taxonomyReference: { recordId: catalogId, revision: 1 },
    availability,
    draft: {
      ...draft,
      maximumAttempts: 3,
      cooldownSeconds: 0,
      rubric: {
        ...draft.rubric,
        reference: { recordId: 'synthetic-submission-rubric', revision: 1 },
      },
    },
  };
}
const publish = (revision = 0, availability = 'AVAILABLE') =>
  runCommandTransaction(db, (tx) =>
    publishPracticeTrialDefinition(
      tx,
      {
        actor: publisher,
        input: definitionInput(revision, availability),
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-definition',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
const begin = (a = subject) =>
  runCommandTransaction(db, (tx) =>
    startPracticeTrial(
      tx,
      {
        actor: a,
        input: {
          version: 'v1',
          definitionReference: { recordId: trialId, revision: 1 },
          accommodationReference: null,
        },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-start',
      },
      { allowNewWrites: true },
    ),
  );
function input() {
  return {
    version: 'v1',
    startId,
    expectedDefinitionReference: { recordId: trialId, revision: 1 },
    expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
    answer: '\n  const answer = "<script>literal</script>";\r\n',
    explanation: 'I can explain and modify this invented solution.',
    toolsUsed: ['editor'],
    aiAssistanceUsed: false,
    assistanceDisclosure: 'No AI assistance declared.',
  };
}
const submit = (a = subject, body: unknown = input(), key = randomUUID(), enabled = true) =>
  runCommandTransaction(db, (tx) =>
    submitPracticeTrial(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-submit' },
      { allowNewWrites: enabled },
    ),
  );

let evaluator: SkillTaxonomyActor, submissionId: string;
const policy: PracticeReviewAssignmentOptions = {
  allowNewWrites: true,
  canManage: (s) =>
    s.issuerAccountId === publisher.accountId &&
    s.evaluatorAccountId === evaluator.accountId &&
    s.subjectAccountId === subject.accountId &&
    s.participantId === participantId &&
    s.skillId === 'frontend',
};
const grantInput = () => ({
  version: 'v1',
  submissionId,
  evaluatorAccountId: evaluator.accountId,
  purpose: 'OWNERSHIP_REVIEW',
  expiresAt: new Date(Date.now() + 60000).toISOString(),
  reason: 'Synthetic bounded ownership review.',
});
const issue = (body: unknown = grantInput(), a = publisher, opts = policy, key = randomUUID()) =>
  runCommandTransaction(db, (tx) =>
    issuePracticeReviewAssignment(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-issue' },
      opts,
    ),
  );
const revoke = (
  id: string,
  a = publisher,
  opts = policy,
  key = randomUUID(),
  reason = 'Synthetic case access revoked.',
) =>
  runCommandTransaction(db, (tx) =>
    revokePracticeReviewAssignment(
      tx,
      {
        actor: a,
        input: { version: 'v1', assignmentId: id, reason },
        idempotencyKey: key,
        requestId: 'synthetic-revoke',
      },
      opts,
    ),
  );

import {
  publishPracticeReviewPolicy,
  observeApprovedPracticeReviewPolicy,
  type PracticeReviewPolicyOptions,
} from '../src/skills/practice-review-policy-storage';
const policyId = 'synthetic-ownership-policy';
let assignmentId: string;
const policyInput = () => ({
  version: 'v1',
  policyId,
  expectedRevision: 0,
  definitionReference: { recordId: trialId, revision: 1 },
  purpose: 'OWNERSHIP_REVIEW',
  state: 'APPROVED',
  guidance:
    'Synthetic manual review guidance; original accepted rubric/tool rules remain authoritative.',
});
const publicationOptions: PracticeReviewPolicyOptions = {
  allowNewWrites: true,
  canPublish: (scope) =>
    scope.accountId === publisher.accountId &&
    scope.definitionReference.recordId === trialId &&
    scope.skillId === 'frontend',
};
const publishPolicy = (
  body: unknown = policyInput(),
  a = publisher,
  options = publicationOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    publishPracticeReviewPolicy(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-policy' },
      options,
    ),
  );

import {
  PracticeTrialOwnershipRecordSchema,
  PracticeTrialOwnershipViewSchema,
  type PracticeTrialOwnershipOptions,
  recordPracticeTrialOwnership,
  readPracticeTrialOwnership,
} from '../src/skills/practice-trial-ownership-storage';
const ownershipInput = () => ({
  version: 'v1',
  assignmentId,
  submissionId,
  expectedSubmissionReference: { recordId: submissionId, revision: 1 },
  expectedDefinitionReference: { recordId: trialId, revision: 1 },
  expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
  expectedPolicyReference: { recordId: policyId, revision: 1 },
  expectedOwnershipReference: null,
  decision: 'CONFIRM',
  reason: 'Synthetic evaluator observed explanation and modification under original rules.',
  observations: [
    {
      kind: 'EXPLANATION',
      detail: 'Synthetic explanation reviewed against saved original solution.',
    },
    { kind: 'MODIFICATION', detail: 'Synthetic bounded modification observed.' },
  ],
});
const ownershipOptions: PracticeTrialOwnershipOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canReview: () => true,
};
const recordOwnership = (
  body: unknown = ownershipInput(),
  a = evaluator,
  options = ownershipOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeTrialOwnership(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-ownership' },
      options,
    ),
  );
const readOwnership = (
  revision: number | undefined = undefined,
  a = evaluator,
  id = assignmentId,
  purpose = 'OWNERSHIP_REVIEW',
  canRead = ownershipOptions.canRead,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeTrialOwnership(
      tx,
      a,
      { version: 'v1', assignmentId: id, submissionId, purpose, revision },
      canRead,
    ),
  );
import {
  recordPracticeTrialAssessment,
  readPracticeTrialAssessment,
} from '../src/skills/practice-trial-assessment-storage';
let assessmentAssignmentId: string,
  confirmedOwnershipReference: { recordId: string; revision: number };
const assessmentPolicyId = 'synthetic-assessment-policy';
const assessmentInput = () => ({
  version: 'v1',
  assignmentId: assessmentAssignmentId,
  submissionId,
  expectedSubmissionReference: { recordId: submissionId, revision: 1 },
  expectedDefinitionReference: { recordId: trialId, revision: 1 },
  expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
  expectedPolicyReference: { recordId: assessmentPolicyId, revision: 1 },
  expectedOwnershipReference: confirmedOwnershipReference,
  expectedReviewReference: null,
  expectedAssessmentReference: null,
  decision: 'VERIFY',
  reason: 'Synthetic authorized reviewer applied original manual pass conditions.',
  confidenceStatement: 'One actual invented case; no broad expertise guarantee.',
  criteria: fixture.rubric.criteria.map((c) => ({
    criterionId: c.id,
    result: 'MET',
    reason: 'Synthetic criterion observation ' + c.id,
  })),
  reassessmentAt: null,
});
const assessmentOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canReview: () => true,
};
const recordAssessment = (
  body: unknown = assessmentInput(),
  a = evaluator,
  options = assessmentOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeTrialAssessment(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-assessment' },
      options,
    ),
  );
const readAssessment = (
  revision: number | undefined = undefined,
  a = evaluator,
  id = assessmentAssignmentId,
  canRead = assessmentOptions.canRead,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeTrialAssessment(
      tx,
      a,
      { version: 'v1', assignmentId: id, submissionId, revision },
      canRead,
    ),
  );
integration('T013D5 actual manual assessment storage', () => {
  beforeAll(() => assertTestDatabase());
  beforeEach(async () => {
    await truncateAll(db);
    publisher = await actor(true, false);
    subject = await actor();
    evaluator = await actor(false, false);
    await publishCatalog();
    await publish();
    const s = await begin();
    startId = s.start.id;
    participantId = s.start.participantId;
    submissionId = (await submit()).submission.reference.recordId;
    assignmentId = (await issue()).assignment.id;
    await publishPolicy();
    confirmedOwnershipReference = (await recordOwnership()).view.record.reference;
    assessmentAssignmentId = (await issue({ ...grantInput(), purpose: 'ASSESSMENT_REVIEW' }))
      .assignment.id;
    await publishPolicy({
      ...policyInput(),
      policyId: assessmentPolicyId,
      purpose: 'ASSESSMENT_REVIEW',
    });
  });
  afterAll(() => db.$disconnect());
  it('commits actual manual VERIFIED rank from original case/criteria/current ownership/approved policy rather than a claimant declaration or proposal', async () => {
    const r = await recordAssessment();
    expect(r.status).toBe('EXECUTED');
    expect(r.view.review).toMatchObject({
      reference: { recordId: submissionId, revision: 1 },
      assignmentId: assessmentAssignmentId,
      evaluatorAccountId: evaluator.accountId,
      decision: 'VERIFY',
      createsVerifiedAssessment: true,
      persisted: true,
      isAuthorizationToken: false,
      createsPermissionGrant: false,
      consumesCapacity: false,
      createsFinancialObligation: false,
    });
    expect(r.view.assessment).toMatchObject({
      version: 'v1',
      participantId,
      skillId: 'frontend',
      skillDomain: 'web',
      state: 'VERIFIED',
      assessedRank: 'A',
      submissionReference: { recordId: submissionId, revision: 1 },
      definitionReference: { recordId: trialId, revision: 1 },
      rubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
      assessmentPolicyVersion: r.view.review.policyVersionId,
      evaluatorAccountId: evaluator.accountId,
      sampleSize: 1,
      evidenceReferences: [{ recordId: submissionId, revision: 1 }],
    });
    expect(r.view.isCurrentReview).toBe(true);
    expect(r.view.isCurrentAssessment).toBe(true);
    expect(
      (
        await runCommandTransaction(db, (tx) =>
          readPracticeTrialSubmission(tx, subject, submissionId),
        )
      )?.ownership,
    ).toBe('UNCONFIRMED');
    expect(await db.outboxEvent.count()).toBe(0);
  });
  it('has no assessment/review from confirmed ownership alone', async () => {
    expect(await readAssessment()).toBeNull();
    expect(await db.$queryRawUnsafe('SELECT count(*)::int n FROM "SkillAssessment"')).toEqual([
      { n: 0 },
    ]);
  });
  it.each(['MORE_EVIDENCE', 'NOT_DEMONSTRATED'])(
    'records reasoned %s without creating a skill assessment',
    async (decision) => {
      const r = await recordAssessment({ ...assessmentInput(), decision });
      expect(r.view.review).toMatchObject({ decision, createsVerifiedAssessment: false });
      expect(r.view.assessment).toBeNull();
      expect(await db.$queryRawUnsafe('SELECT count(*)::int n FROM "SkillAssessment"')).toEqual([
        { n: 0 },
      ]);
    },
  );
  it('does not silently revoke or downgrade an existing VERIFIED assessment when a later review needs more evidence', async () => {
    const first = await recordAssessment();
    const next = await recordAssessment({
      ...assessmentInput(),
      expectedReviewReference: first.view.review.reference,
      expectedAssessmentReference: first.view.assessment!.reference,
      decision: 'MORE_EVIDENCE',
    });
    expect(next.view.assessment).toBeNull();
    expect(next.view.currentAssessmentReference).toEqual(first.view.assessment!.reference);
    expect((await readAssessment(1))?.assessment).toEqual(first.view.assessment);
    expect((await readAssessment(1))?.isCurrentAssessment).toBe(true);
    expect(
      await db.$queryRawUnsafe('SELECT count(*)::int n FROM "SkillAssessmentVersion"'),
    ).toEqual([{ n: 1 }]);
  });
  it('appends actual verification history without inflating the sample size of repeated review of the same evidence', async () => {
    const first = await recordAssessment();
    const next = await recordAssessment({
      ...assessmentInput(),
      expectedReviewReference: first.view.review.reference,
      expectedAssessmentReference: first.view.assessment!.reference,
    });
    expect(next.view.review.reference.revision).toBe(2);
    expect(next.view.assessment!.reference).toEqual({
      ...first.view.assessment!.reference,
      revision: 2,
    });
    expect(next.view.assessment!.sampleSize).toBe(1);
    expect((await readAssessment(1))?.isCurrentAssessment).toBe(false);
    expect((await readAssessment(1))?.assessment).toEqual(first.view.assessment);
  });
  it('recovers the original historical result after correction/writeoff/policy withdrawal under current case read authority', async () => {
    const key = randomUUID(),
      body = assessmentInput(),
      first = await recordAssessment(body, evaluator, assessmentOptions, key);
    await recordAssessment({
      ...body,
      expectedReviewReference: first.view.review.reference,
      expectedAssessmentReference: first.view.assessment!.reference,
    });
    await publishPolicy({
      ...policyInput(),
      policyId: assessmentPolicyId,
      purpose: 'ASSESSMENT_REVIEW',
      expectedRevision: 1,
      state: 'WITHDRAWN',
    });
    const replay = await recordAssessment(
      body,
      evaluator,
      {
        ...assessmentOptions,
        allowNewWrites: false,
        canReview: () => false,
        canUsePolicy: () => false,
      },
      key,
    );
    expect(replay.status).toBe('REPLAYED');
    expect(replay.view.review).toEqual(first.view.review);
    expect(replay.view.assessment).toEqual(first.view.assessment);
    expect(replay.view.isCurrentReview).toBe(false);
    expect(replay.view.isCurrentAssessment).toBe(false);
  });
  it('rejects changed same-key body using the shared receipt contract', async () => {
    const key = randomUUID();
    await recordAssessment(assessmentInput(), evaluator, assessmentOptions, key);
    await expect(
      recordAssessment(
        { ...assessmentInput(), reason: 'Changed' },
        evaluator,
        assessmentOptions,
        key,
      ),
    ).rejects.toMatchObject({ code: 'IDEMPOTENCY_KEY_REUSED' });
  });
  it('CAS protects both review and participant-skill source under simultaneous decisions', async () => {
    const r = await Promise.allSettled([
      recordAssessment(),
      recordAssessment({ ...assessmentInput(), decision: 'MORE_EVIDENCE' }),
    ]);
    expect(r.filter((x) => x.status === 'fulfilled')).toHaveLength(1);
    expect(r.find((x) => x.status === 'rejected')).toMatchObject({
      reason: { code: 'REVISION_CHANGED' },
    });
  });
  it.each([
    'expectedSubmissionReference',
    'expectedDefinitionReference',
    'expectedRubricReference',
    'expectedPolicyReference',
    'expectedOwnershipReference',
    'expectedReviewReference',
    'expectedAssessmentReference',
  ])('rejects stale or foreign %s', async (field) => {
    await expect(
      recordAssessment({ ...assessmentInput(), [field]: { recordId: 'foreign', revision: 1 } }),
    ).rejects.toMatchObject({ code: 'REVISION_CHANGED' });
  });
  it('requires a current confirmed ownership source even when every criterion is MET', async () => {
    const current = await recordOwnership({
      ...ownershipInput(),
      expectedOwnershipReference: confirmedOwnershipReference,
      decision: 'MORE_EVIDENCE',
    });
    await expect(
      recordAssessment({
        ...assessmentInput(),
        expectedOwnershipReference: current.view.record.reference,
      }),
    ).rejects.toMatchObject({ code: 'EVIDENCE_NOT_CONFIRMED' });
  });
  it('requires every original required criterion MET and exact criterion coverage', async () => {
    await expect(
      recordAssessment({ ...assessmentInput(), criteria: assessmentInput().criteria.slice(0, 1) }),
    ).rejects.toMatchObject({ code: 'INVALID_INPUT' });
    await expect(
      recordAssessment({
        ...assessmentInput(),
        criteria: assessmentInput().criteria.map((c) => ({ ...c, result: 'UNCERTAIN' })),
      }),
    ).rejects.toMatchObject({ code: 'RUBRIC_NOT_MET' });
  });
  it('cannot substitute ownership appointment, admin role or claimant for current assessment appointment', async () => {
    await expect(recordAssessment({ ...assessmentInput(), assignmentId })).rejects.toMatchObject({
      code: 'RESOURCE_UNAVAILABLE',
    });
    await expect(recordAssessment(assessmentInput(), publisher)).rejects.toMatchObject({
      code: 'RESOURCE_UNAVAILABLE',
    });
    await expect(recordAssessment(assessmentInput(), subject)).rejects.toMatchObject({
      code: 'RESOURCE_UNAVAILABLE',
    });
  });
  it('denies lost own evaluator session for new decisions and original retries', async () => {
    const key = randomUUID();
    await recordAssessment(assessmentInput(), evaluator, assessmentOptions, key);
    await db.session.delete({ where: { tokenHash: evaluator.sessionHash } });
    await expect(
      recordAssessment(assessmentInput(), evaluator, assessmentOptions, key),
    ).rejects.toMatchObject({ code: 'AUTHENTICATION_REQUIRED' });
  });
  it('denies revoked current assignment for new writes/read/replay', async () => {
    const key = randomUUID();
    await recordAssessment(assessmentInput(), evaluator, assessmentOptions, key);
    await revoke(assessmentAssignmentId);
    expect(await readAssessment()).toBeNull();
    await expect(
      recordAssessment(assessmentInput(), evaluator, assessmentOptions, key),
    ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
  });
  it('denies withdrawn actual policy rather than treating a client label as approval', async () => {
    await publishPolicy({
      ...policyInput(),
      policyId: assessmentPolicyId,
      purpose: 'ASSESSMENT_REVIEW',
      expectedRevision: 1,
      state: 'WITHDRAWN',
    });
    await expect(
      recordAssessment({
        ...assessmentInput(),
        expectedPolicyReference: { recordId: assessmentPolicyId, revision: 2 },
      }),
    ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
  });
  it('preserves off-state without creating a new review/rank or successful command receipt', async () => {
    await expect(
      recordAssessment(assessmentInput(), evaluator, {
        ...assessmentOptions,
        allowNewWrites: false,
      }),
    ).rejects.toMatchObject({ code: 'WRITES_DISABLED' });
    expect(
      await db.commandReceipt.count({ where: { commandKind: 'RecordPracticeTrialAssessment' } }),
    ).toBe(0);
  });
  it.each(['canRead', 'canUsePolicy', 'canReview'])(
    'fails closed on current %s denial',
    async (field) => {
      await expect(
        recordAssessment(assessmentInput(), evaluator, {
          ...assessmentOptions,
          [field]: () => false,
        }),
      ).rejects.toMatchObject({ code: 'RESOURCE_UNAVAILABLE' });
    },
  );
  it.each([
    { assessedRank: 'S' },
    { sampleSize: 1000 },
    { assessmentPolicyVersion: 'client-approved' },
    { approved: true },
    { evidenceReferences: [{ recordId: 'guessed', revision: 1 }] },
  ])('rejects caller-invented committed facts %s', async (patch) => {
    await expect(recordAssessment({ ...assessmentInput(), ...patch })).rejects.toMatchObject({
      code: 'INVALID_INPUT',
    });
  });
  it.each(['', '😀'.repeat(1001), 'x\0', 'x\ud800'])(
    'rejects malformed private reason before any persistence %s',
    async (reason) => {
      await expect(recordAssessment({ ...assessmentInput(), reason })).rejects.toMatchObject({
        code: 'INVALID_INPUT',
      });
    },
  );
  it('returns private history only to the exact actual current assessment reviewer', async () => {
    const r = await recordAssessment();
    expect(await readAssessment(undefined, publisher)).toBeNull();
    expect(await readAssessment(undefined, evaluator, assignmentId)).toBeNull();
    expect((await readAssessment())?.review).toEqual(r.view.review);
  });
});
