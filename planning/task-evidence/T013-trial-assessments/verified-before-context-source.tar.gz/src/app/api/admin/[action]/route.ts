import { NextResponse } from 'next/server';
import { checkOrigin, requireUser, HttpError } from '@/lib/auth';
import { db } from '@/lib/db';
import { settingsInput } from '@/lib/validation';
import { z } from 'zod';
import { failure, readJson } from '@/lib/http';
import { releaseFundedRaid } from '@/lib/studio-finance';
import { fundingPricing, fundingQuote } from '@/lib/raid-funding';
import { assertLaunchpadsAvailable } from '@/lib/release';
export async function POST(request: Request, { params }: { params: Promise<{ action: string }> }) {
  try {
    checkOrigin(request);
    const user = await requireUser(true);
    const { action } = await params;
    const b = await readJson(
      request,
      z
        .object({ reason: z.string().max(5000).optional(), id: z.string().max(100).optional() })
        .passthrough(),
    );
    const reason = typeof b.reason === 'string' ? b.reason.trim().slice(0, 500) : '';
    if (!reason) throw new HttpError(400, 'A reason is required for the audit log.');
    if (action === 'raid-release') {
      if (typeof b.id !== 'string') throw new HttpError(400, 'Invalid Raid.');
      await releaseFundedRaid(b.id, user.id, reason);
      return NextResponse.json({ ok: true });
    }
    await db.$transaction(async (tx) => {
      await tx.$executeRaw`SELECT pg_advisory_xact_lock(729103)`;
      if (action === 'settings')
        await tx.settings.upsert({
          where: { id: 'global' },
          create: settingsInput.parse(b),
          update: settingsInput.parse(b),
        });
      else if (action === 'finance') {
        if (typeof b.launchPaused !== 'boolean' || typeof b.payoutPaused !== 'boolean')
          throw new HttpError(400, 'Invalid finance switches.');
        await tx.settings.upsert({
          where: { id: 'global' },
          create: { launchPaused: b.launchPaused, payoutPaused: b.payoutPaused },
          update: { launchPaused: b.launchPaused, payoutPaused: b.payoutPaused },
        });
      } else if (action === 'launch-resume') {
        assertLaunchpadsAvailable();
        const launch = await tx.tokenLaunch.findUnique({ where: { id: b.id } });
        if (!launch || launch.status !== 'PAUSED')
          throw new HttpError(409, 'Launch is not paused.');
        if (
          await tx.financialTx.count({
            where: {
              launchId: launch.id,
              status: 'SIGNED',
              createdAt: { gt: new Date(Date.now() - 600000) },
            },
          })
        )
          throw new HttpError(409, 'Resolve signed transaction first.');
        await tx.tokenLaunch.update({ where: { id: b.id }, data: { status: 'LIVE', error: null } });
      } else if (action === 'funding-quote') {
        const raid = await tx.raid.findUnique({ where: { id: b.id } });
        const pricing = fundingPricing();
        if (
          !raid ||
          raid.studioVersion === 1 ||
          raid.mint ||
          raid.status !== 'DRAFT' ||
          raid.fundingSignature ||
          !raid.impressionTarget ||
          !pricing
        )
          throw new HttpError(409, 'Funding quote unavailable for this draft.');
        await tx.raid.update({
          where: { id: raid.id },
          data: {
            fundingLamports: fundingQuote(raid.impressionTarget, pricing.lamportsPerThousand),
            fundingRecipient: pricing.recipient,
          },
        });
      } else if (action === 'creator') {
        if (typeof b.suspended !== 'boolean') throw new HttpError(400, 'Invalid creator status.');
        const target = await tx.user.findUniqueOrThrow({ where: { id: b.id } });
        if (target.id === user.id) throw new HttpError(400, 'You cannot change your own access.');
        await tx.user.update({ where: { id: b.id }, data: { suspended: b.suspended } });
        if (b.suspended) await tx.session.deleteMany({ where: { userId: b.id } });
      } else if (action === 'raid' || action === 'post') {
        if (typeof b.hidden !== 'boolean') throw new HttpError(400, 'Invalid visibility.');
        if (action === 'raid')
          await tx.raid.update({ where: { id: b.id }, data: { hidden: b.hidden } });
        else {
          const current = await tx.post.findUniqueOrThrow({
            where: { id: b.id },
            include: { raid: true },
          });
          if (current.raid.trackingVersion === 2)
            throw new HttpError(409, 'Use the contribution review controls for this post.');
          const post = await tx.post.update({ where: { id: b.id }, data: { hidden: b.hidden } });
          // Historical comparisons are invalid after a moderation decision.
          await tx.snapshot.updateMany({
            where: { raidId: post.raidId },
            data: { complete: false },
          });
        }
      } else if (action === 'retry') {
        if (typeof b.id !== 'string') throw new HttpError(400, 'Invalid job.');
        const stale = new Date(Date.now() - 600000);
        const job = await tx.job.findUnique({ where: { id: b.id } });
        const reset = await tx.job.updateMany({
          where: {
            id: b.id,
            doneAt: null,
            error: { not: null },
            OR: [{ lockedAt: null }, { lockedAt: { lt: stale } }],
          },
          data: {
            attempts: 0,
            error: null,
            failedAt: null,
            lockedAt: null,
            lease: null,
            runAt: new Date(),
          },
        });
        if (reset.count !== 1)
          throw new HttpError(409, 'Only failed jobs that are not running can be retried.');
        const submissionId = (job?.payload as { submissionId?: string } | null)?.submissionId;
        if (job?.kind === 'submission' && submissionId)
          await tx.postSubmission.updateMany({
            where: { id: submissionId, status: 'EXCLUDED', reasonCode: 'LOOKUP_FAILED' },
            data: { status: 'QUEUED', reasonCode: null },
          });
      } else throw new HttpError(400, 'Unsupported admin action.');
      await tx.moderationEvent.create({
        data: { actorId: user.id, action, targetId: b.id || 'global', reason },
      });
    });
    return NextResponse.json({ ok: true });
  } catch (e) {
    return failure(e);
  }
}
