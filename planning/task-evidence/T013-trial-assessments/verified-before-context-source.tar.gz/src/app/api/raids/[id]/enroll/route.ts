import { NextResponse } from 'next/server';
import { checkOrigin, requireUser } from '@/lib/auth';
import { enrollRaid } from '@/lib/tracking';
import { failure } from '@/lib/http';
export async function POST(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    checkOrigin(request);
    const user = await requireUser();
    return NextResponse.json(await enrollRaid((await params).id, user.id));
  } catch (error) {
    return failure(error);
  }
}
