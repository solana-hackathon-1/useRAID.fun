// Typed RED placeholders before Root composition.
export function practiceTrialAssessmentWriteConfiguration(): unknown {
  return undefined;
}
export async function recordPracticeTrialAssessmentFromHost(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialAssessmentFromHost(..._args: unknown[]): Promise<never> {
  throw new Error('NOT_IMPLEMENTED');
}
