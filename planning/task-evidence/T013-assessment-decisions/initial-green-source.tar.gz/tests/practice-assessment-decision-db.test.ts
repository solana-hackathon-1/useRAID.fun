import { lockApprovedPracticeReviewPolicy } from '../src/skills/practice-review-policy-storage';
import { readPracticeTrialForReview } from '../src/skills/practice-review-read-storage';
import { randomUUID } from 'node:crypto';
import { afterAll, beforeAll, beforeEach, describe, expect, it } from 'vitest';
import { db } from '../src/lib/db';
import { hash } from '../src/lib/auth-primitives';
import { runCommandTransaction } from '../src/lib/command-receipts-adapter';
import { executeIdempotentCommand, type CommandOutcome } from '../src/command-receipts';
import { publishSkillTaxonomy, type SkillTaxonomyActor } from '../src/skills/taxonomy-storage';
import { publishPracticeTrialDefinition } from '../src/skills/practice-trial-storage';
import { startPracticeTrial } from '../src/skills/practice-trial-attempt-storage';
import {
  submitPracticeTrial,
  readPracticeTrialSubmission,
} from '../src/skills/practice-trial-submission-storage';
import {
  issuePracticeReviewAssignment,
  revokePracticeReviewAssignment,
  type PracticeReviewAssignmentOptions,
} from '../src/skills/practice-review-assignment-storage';
import { definition as fixture } from '../examples/skill-assessments/fixtures';
import { assertTestDatabase, truncateAll } from './helpers/db-guard';
const integration = process.env.RUN_DB_TESTS === 'true' ? describe : describe.skip;
const catalogId = 'synthetic-submission-catalog',
  trialId = 'synthetic-submission-trial';
let publisher: SkillTaxonomyActor,
  subject: SkillTaxonomyActor,
  startId: string,
  participantId: string;
const skills = [
  { id: 'frontend', domain: 'web', name: 'Frontend', status: 'ACTIVE', aliases: ['frontend'] },
];
async function actor(admin = false, mapped = true) {
  const user = await db.user.create({
    data: {
      handle: 'synthetic',
      role: admin ? 'ADMIN' : 'CREATOR',
      xId: admin ? randomUUID() : null,
    },
  });
  const sessionHash = hash(randomUUID());
  await db.session.create({
    data: {
      tokenHash: sessionHash,
      userId: user.id,
      via: admin ? 'x' : 'wallet',
      expiresAt: new Date(Date.now() + 60000),
    },
  });
  if (mapped)
    await db.participant.create({
      data: {
        accountId: user.id,
        provisionActorAccountId: user.id,
        provisionRequestId: 'synthetic-provision',
      },
    });
  return { accountId: user.id, sessionHash };
}
const publishCatalog = (revision = 0, entries: unknown = skills) =>
  runCommandTransaction(db, (tx) =>
    publishSkillTaxonomy(
      tx,
      {
        actor: publisher,
        input: { taxonomyId: catalogId, expectedRevision: revision, skills: entries },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-catalog',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
function definitionInput(revision = 0, availability = 'AVAILABLE') {
  const draft = structuredClone(fixture);
  for (const field of ['reference', 'publishedAt', 'state']) Reflect.deleteProperty(draft, field);
  return {
    trialId,
    expectedRevision: revision,
    taxonomyReference: { recordId: catalogId, revision: 1 },
    availability,
    draft: {
      ...draft,
      maximumAttempts: 3,
      cooldownSeconds: 0,
      rubric: {
        ...draft.rubric,
        reference: { recordId: 'synthetic-submission-rubric', revision: 1 },
      },
    },
  };
}
const publish = (revision = 0, availability = 'AVAILABLE') =>
  runCommandTransaction(db, (tx) =>
    publishPracticeTrialDefinition(
      tx,
      {
        actor: publisher,
        input: definitionInput(revision, availability),
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-definition',
      },
      { allowNewWrites: true, canPublish: () => true },
    ),
  );
const begin = (a = subject) =>
  runCommandTransaction(db, (tx) =>
    startPracticeTrial(
      tx,
      {
        actor: a,
        input: {
          version: 'v1',
          definitionReference: { recordId: trialId, revision: 1 },
          accommodationReference: null,
        },
        idempotencyKey: randomUUID(),
        requestId: 'synthetic-start',
      },
      { allowNewWrites: true },
    ),
  );
function input() {
  return {
    version: 'v1',
    startId,
    expectedDefinitionReference: { recordId: trialId, revision: 1 },
    expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
    answer: '\n  const answer = "<script>literal</script>";\r\n',
    explanation: 'I can explain and modify this invented solution.',
    toolsUsed: ['editor'],
    aiAssistanceUsed: false,
    assistanceDisclosure: 'No AI assistance declared.',
  };
}
const submit = (a = subject, body: unknown = input(), key = randomUUID(), enabled = true) =>
  runCommandTransaction(db, (tx) =>
    submitPracticeTrial(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-submit' },
      { allowNewWrites: enabled },
    ),
  );

let evaluator: SkillTaxonomyActor, submissionId: string;
const policy: PracticeReviewAssignmentOptions = {
  allowNewWrites: true,
  canManage: (s) =>
    s.issuerAccountId === publisher.accountId &&
    s.evaluatorAccountId === evaluator.accountId &&
    s.subjectAccountId === subject.accountId &&
    s.participantId === participantId &&
    s.skillId === 'frontend',
};
const grantInput = () => ({
  version: 'v1',
  submissionId,
  evaluatorAccountId: evaluator.accountId,
  purpose: 'OWNERSHIP_REVIEW',
  expiresAt: new Date(Date.now() + 60000).toISOString(),
  reason: 'Synthetic bounded ownership review.',
});
const issue = (body: unknown = grantInput(), a = publisher, opts = policy, key = randomUUID()) =>
  runCommandTransaction(db, (tx) =>
    issuePracticeReviewAssignment(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-issue' },
      opts,
    ),
  );
const revoke = (
  id: string,
  a = publisher,
  opts = policy,
  key = randomUUID(),
  reason = 'Synthetic case access revoked.',
) =>
  runCommandTransaction(db, (tx) =>
    revokePracticeReviewAssignment(
      tx,
      {
        actor: a,
        input: { version: 'v1', assignmentId: id, reason },
        idempotencyKey: key,
        requestId: 'synthetic-revoke',
      },
      opts,
    ),
  );

import {
  publishPracticeReviewPolicy,
  type PracticeReviewPolicyOptions,
} from '../src/skills/practice-review-policy-storage';
const policyId = 'synthetic-ownership-policy';
let assignmentId: string;
const policyInput = () => ({
  version: 'v1',
  policyId,
  expectedRevision: 0,
  definitionReference: { recordId: trialId, revision: 1 },
  purpose: 'OWNERSHIP_REVIEW',
  state: 'APPROVED',
  guidance:
    'Synthetic manual review guidance; original accepted rubric/tool rules remain authoritative.',
});
const publicationOptions: PracticeReviewPolicyOptions = {
  allowNewWrites: true,
  canPublish: (scope) =>
    scope.accountId === publisher.accountId &&
    scope.definitionReference.recordId === trialId &&
    scope.skillId === 'frontend',
};
const publishPolicy = (
  body: unknown = policyInput(),
  a = publisher,
  options = publicationOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    publishPracticeReviewPolicy(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-policy' },
      options,
    ),
  );

import {
  type PracticeTrialOwnershipOptions,
  recordPracticeTrialOwnership,
  readPracticeTrialOwnership,
} from '../src/skills/practice-trial-ownership-storage';
const ownershipInput = () => ({
  version: 'v1',
  assignmentId,
  submissionId,
  expectedSubmissionReference: { recordId: submissionId, revision: 1 },
  expectedDefinitionReference: { recordId: trialId, revision: 1 },
  expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
  expectedPolicyReference: { recordId: policyId, revision: 1 },
  expectedOwnershipReference: null,
  decision: 'CONFIRM',
  reason: 'Synthetic evaluator observed explanation and modification under original rules.',
  observations: [
    {
      kind: 'EXPLANATION',
      detail: 'Synthetic explanation reviewed against saved original solution.',
    },
    { kind: 'MODIFICATION', detail: 'Synthetic bounded modification observed.' },
  ],
});
const ownershipOptions: PracticeTrialOwnershipOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canReview: () => true,
};
const recordOwnership = (
  body: unknown = ownershipInput(),
  a = evaluator,
  options = ownershipOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeTrialOwnership(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-ownership' },
      options,
    ),
  );

import {
  observePracticeTrialAssessmentContext,
  PracticeTrialAssessmentViewSchema,
  type PracticeTrialAssessmentOptions,
  recordPracticeTrialAssessment,
  readPracticeTrialAssessment,
} from '../src/skills/practice-trial-assessment-storage';
let assessmentAssignmentId: string,
  confirmedOwnershipReference: { recordId: string; revision: number };
const assessmentPolicyId = 'synthetic-assessment-policy';
const assessmentInput = () => ({
  version: 'v1',
  assignmentId: assessmentAssignmentId,
  submissionId,
  expectedSubmissionReference: { recordId: submissionId, revision: 1 },
  expectedDefinitionReference: { recordId: trialId, revision: 1 },
  expectedRubricReference: { recordId: 'synthetic-submission-rubric', revision: 1 },
  expectedPolicyReference: { recordId: assessmentPolicyId, revision: 1 },
  expectedOwnershipReference: confirmedOwnershipReference,
  expectedReviewReference: null,
  expectedAssessmentReference: null,
  decision: 'VERIFY',
  reason: 'Synthetic authorized reviewer applied original manual pass conditions.',
  confidenceStatement: 'One actual invented case; no broad expertise guarantee.',
  criteria: fixture.rubric.criteria.map((c) => ({
    criterionId: c.id,
    result: 'MET',
    reason: 'Synthetic criterion observation ' + c.id,
  })),
  reassessmentAt: null,
});
const assessmentOptions: PracticeTrialAssessmentOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canReview: () => true,
};
const recordAssessment = (
  body: unknown = assessmentInput(),
  a = evaluator,
  options = assessmentOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeTrialAssessment(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-assessment' },
      options,
    ),
  );
const readAssessment = (
  revision: number | undefined = undefined,
  a = evaluator,
  id = assessmentAssignmentId,
  canRead = assessmentOptions.canRead,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeTrialAssessment(
      tx,
      a,
      { version: 'v1', assignmentId: id, submissionId, revision },
      canRead,
    ),
  );
import {
  recordPracticeAssessmentDecision,
  readPracticeTrialAssessmentState,
} from '../src/skills/practice-trial-assessment-storage';
let issued: Awaited<ReturnType<typeof recordAssessment>>;
const decisionOptions = {
  allowNewWrites: true,
  canRead: () => true,
  canUsePolicy: () => true,
  canDecide: () => true,
};
const decisionInput = (action = 'REQUIRE_REASSESSMENT') => ({
  version: 'v1',
  assignmentId: assessmentAssignmentId,
  submissionId,
  expectedAssessmentReference: issued.view.assessment!.reference,
  expectedReviewReference: issued.view.review.reference,
  expectedOwnershipReference: confirmedOwnershipReference,
  expectedPolicyReference: { recordId: assessmentPolicyId, revision: 1 },
  action,
  reasonCategory: action === 'REVOKE' ? 'FRAUDULENT_ASSESSMENT_EVIDENCE' : 'CAPABILITY_RECHECK',
  reason: 'Synthetic authorized reasoned original-case decision.',
  findings: [
    {
      kind: action === 'REVOKE' ? 'ASSESSMENT_EVIDENCE' : 'CAPABILITY_EVIDENCE',
      detail: 'Specific synthetic original-case observation; no automatic inference from a signal.',
    },
  ],
  dueAt: action === 'REVOKE' ? null : new Date(Date.now() + 3600000).toISOString(),
});
const decide = (
  body: unknown = decisionInput(),
  a = evaluator,
  options = decisionOptions,
  key = randomUUID(),
) =>
  runCommandTransaction(db, (tx) =>
    recordPracticeAssessmentDecision(
      tx,
      { actor: a, input: body, idempotencyKey: key, requestId: 'synthetic-assessment-decision' },
      options,
    ),
  );
const readState = (
  revision: number | undefined = undefined,
  a = evaluator,
  id = assessmentAssignmentId,
  canRead = decisionOptions.canRead,
) =>
  runCommandTransaction(db, (tx) =>
    readPracticeTrialAssessmentState(
      tx,
      a,
      { version: 'v1', assignmentId: id, submissionId, revision },
      canRead,
    ),
  );
integration('T013D6 actual reasoned assessment state decisions', () => {
  beforeAll(() => assertTestDatabase());
  beforeEach(async () => {
    await truncateAll(db);
    publisher = await actor(true, false);
    subject = await actor();
    evaluator = await actor(false, false);
    await publishCatalog();
    await publish();
    const s = await begin();
    startId = s.start.id;
    participantId = s.start.participantId;
    submissionId = (await submit()).submission.reference.recordId;
    assignmentId = (await issue()).assignment.id;
    await publishPolicy();
    confirmedOwnershipReference = (await recordOwnership()).view.record.reference;
    assessmentAssignmentId = (await issue({ ...grantInput(), purpose: 'ASSESSMENT_REVIEW' }))
      .assignment.id;
    await publishPolicy({
      ...policyInput(),
      policyId: assessmentPolicyId,
      purpose: 'ASSESSMENT_REVIEW',
    });
    issued = await recordAssessment();
  });
  afterAll(() => db.$disconnect());

  it('commits capability recheck with actual source history, preserving original rank/evidence/issuer and declaring it no longer current verified', async () => {
    const r = await decide();
    expect(r.status).toBe('EXECUTED');
    expect(r.view.decision).toMatchObject({
      action: 'REQUIRE_REASSESSMENT',
      reasonCategory: 'CAPABILITY_RECHECK',
      priorAssessmentReference: issued.view.assessment!.reference,
      evaluatorAccountId: evaluator.accountId,
      persisted: true,
    });
    expect(r.view.assessment).toMatchObject({
      state: 'REASSESSMENT_REQUIRED',
      assessedRank: 'A',
      sampleSize: 1,
      reference: { recordId: issued.view.assessment!.reference.recordId, revision: 2 },
      evidenceReferences: issued.view.assessment!.evidenceReferences,
    });
    expect(r.view.priorAssessment).toEqual(issued.view.assessment);
    expect(r.view.isCurrent).toBe(true);
    expect((await readAssessment())!.isCurrentAssessment).toBe(false);
    expect((await readAssessment())!.assessment).toEqual(issued.view.assessment);
    expect((await readState())!.assessment.state).toBe('REASSESSMENT_REQUIRED');
    expect((await readState(1))!.isCurrent).toBe(false);
    const events = await db.auditEvent.findMany({
      where: { eventType: 'skill.assessment_reassessment_required.v1' },
    });
    expect(events).toHaveLength(1);
    expect(events[0].payload).toEqual({ practiceAssessmentDecisionId: r.view.decision.id });
    expect(await db.outboxEvent.count({ where: { eventId: events[0].id } })).toBe(0);
  });
  it('commits separate reasoned fraud revocation without account/reputation/capacity/money changes or rewriting original declaration', async () => {
    const r = await decide(decisionInput('REVOKE'));
    expect(r.view.assessment.state).toBe('REVOKED');
    expect(r.view.assessment.reassessmentAt).toBeNull();
    expect(r.view.decision.reasonCategory).toBe('FRAUDULENT_ASSESSMENT_EVIDENCE');
    expect(await db.user.findUniqueOrThrow({ where: { id: subject.accountId } })).toMatchObject({
      suspended: false,
    });
    expect(
      (
        await runCommandTransaction(db, (tx) =>
          readPracticeTrialSubmission(tx, subject, submissionId),
        )
      )?.ownership,
    ).toBe('UNCONFIRMED');
  });
  it('retries original result after writes off, policy withdrawal and later correction; changed input conflicts', async () => {
    const key = randomUUID(),
      body = decisionInput(),
      a = await decide(body, evaluator, decisionOptions, key);
    await decide({
      ...decisionInput('REVOKE'),
      expectedAssessmentReference: a.view.assessment.reference,
    });
    await publishPolicy({
      ...policyInput(),
      policyId: assessmentPolicyId,
      purpose: 'ASSESSMENT_REVIEW',
      expectedRevision: 1,
      state: 'WITHDRAWN',
    });
    const replay = await decide(
      body,
      evaluator,
      {
        ...decisionOptions,
        allowNewWrites: false,
        canUsePolicy: () => false,
        canDecide: () => false,
      },
      key,
    );
    expect(replay.status).toBe('REPLAYED');
    expect(replay.view.decision).toEqual(a.view.decision);
    expect(replay.view.isCurrent).toBe(false);
    expect(replay.view.assessment.state).toBe('REASSESSMENT_REQUIRED');
    await expect(
      decide({ ...body, reason: 'Changed' }, evaluator, decisionOptions, key),
    ).rejects.toMatchObject({ code: 'IDEMPOTENCY_KEY_REUSED' });
  });
  it.each([
    'WRONG_PURPOSE',
    'FOREIGN_ACTOR',
    'REVOKED',
    'READ_POLICY',
    'DECISION_POLICY',
    'WRITE_OFF',
    'SESSION_REVOKED',
    'SUSPENDED',
    'POLICY_WITHDRAWN',
    'POLICY_STALE',
    'ASSESSMENT_STALE',
    'REVIEW_STALE',
    'OWNERSHIP_STALE',
  ])('fails closed for %s without a state change', async (kind) => {
    const body = decisionInput();
    let a = evaluator,
      o = decisionOptions,
      code = 'RESOURCE_UNAVAILABLE';
    if (kind === 'WRONG_PURPOSE') body.assignmentId = assignmentId;
    if (kind === 'FOREIGN_ACTOR') a = await actor(false, false);
    if (kind === 'REVOKED') await revoke(assessmentAssignmentId);
    if (kind === 'READ_POLICY') o = { ...o, canRead: () => false };
    if (kind === 'DECISION_POLICY') o = { ...o, canDecide: () => false };
    if (kind === 'WRITE_OFF') {
      o = { ...o, allowNewWrites: false };
      code = 'WRITES_DISABLED';
    }
    if (kind === 'SESSION_REVOKED')
      await db.session.deleteMany({ where: { tokenHash: evaluator.sessionHash } });
    if (kind === 'SUSPENDED')
      await db.user.update({ where: { id: evaluator.accountId }, data: { suspended: true } });
    if (kind === 'POLICY_WITHDRAWN')
      await publishPolicy({
        ...policyInput(),
        policyId: assessmentPolicyId,
        purpose: 'ASSESSMENT_REVIEW',
        expectedRevision: 1,
        state: 'WITHDRAWN',
      });
    if (kind.endsWith('_STALE')) {
      code = 'REVISION_CHANGED';
      if (kind === 'POLICY_STALE') body.expectedPolicyReference.revision = 9;
      if (kind === 'ASSESSMENT_STALE')
        body.expectedAssessmentReference = { ...body.expectedAssessmentReference, revision: 9 };
      if (kind === 'REVIEW_STALE')
        body.expectedReviewReference = { ...body.expectedReviewReference, revision: 9 };
      if (kind === 'OWNERSHIP_STALE')
        body.expectedOwnershipReference = { ...body.expectedOwnershipReference, revision: 9 };
    }
    await expect(decide(body, a, o)).rejects.toMatchObject({
      code:
        kind === 'SESSION_REVOKED'
          ? 'AUTHENTICATION_REQUIRED'
          : kind === 'SUSPENDED'
            ? 'ACCOUNT_RESTRICTED'
            : code,
    });
    expect(
      (
        await db.$queryRawUnsafe<{ revision: number }[]>('SELECT "revision" FROM "SkillAssessment"')
      )[0].revision,
    ).toBe(1);
  });
  it.each([
    { reason: '' },
    { reason: '😀'.repeat(1001) },
    { reason: 'bad\u0000value' },
    { action: 'REQUIRE_REASSESSMENT', reasonCategory: 'FRAUDULENT_ASSESSMENT_EVIDENCE' },
    { action: 'REVOKE', reasonCategory: 'CAPABILITY_RECHECK' },
    { dueAt: null },
    { dueAt: '2020-01-01T00:00:00.000Z' },
    { findings: [] },
    { findings: [{ kind: 'NETWORK_SIGNAL', detail: 'Shared IP' }] },
    { rank: 'S' },
    { sampleSize: 200 },
  ])('rejects invalid decision input before effect %j', async (patch) => {
    await expect(decide({ ...decisionInput(), ...patch })).rejects.toMatchObject({
      code: 'INVALID_INPUT',
    });
  });
  it('real concurrent decisions from one exact revision produce one effect', async () => {
    const body = decisionInput();
    const r = await Promise.allSettled([decide(body), decide(body)]);
    expect(r.filter((x) => x.status === 'fulfilled')).toHaveLength(1);
    expect(r.filter((x) => x.status === 'rejected')).toHaveLength(1);
    expect(
      await db.auditEvent.count({
        where: { eventType: 'skill.assessment_reassessment_required.v1' },
      }),
    ).toBe(1);
  });
  it('requires a current actual same-case grant for historical state, with private audit before snapshot selection', async () => {
    const r = await readState();
    expect(r!.assessment).toEqual(issued.view.assessment);
    expect(r!.isCurrent).toBe(true);
    expect(r!.accessId).toMatch(/^[0-9a-f-]{36}$/);
    await revoke(assessmentAssignmentId);
    expect(await readState()).toBeNull();
  });
});
