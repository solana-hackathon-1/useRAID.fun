export function createPracticeReviewPageLoader(_get: (request: Request, params: unknown) => Promise<Response>) {
  return async (_params: unknown, _search: unknown): Promise<unknown> => ({ status: 'UNAVAILABLE' });
}
