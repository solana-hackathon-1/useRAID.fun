import type { PracticeReviewReadRecord } from '../skills/practice-review-read-storage';
export function PracticeReviewCase(_props: { review: PracticeReviewReadRecord }) { return null; }
