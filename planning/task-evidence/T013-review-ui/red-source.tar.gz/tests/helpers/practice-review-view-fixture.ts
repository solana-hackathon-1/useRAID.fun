import { definition } from '../../examples/skill-assessments/fixtures';
import { PracticeReviewReadRecordSchema } from '../../src/skills/practice-review-read-storage';
export const reviewScope = {
  version: 'v1' as const,
  assignmentId: '11111111-1111-4111-8111-111111111111',
  submissionId: '22222222-2222-4222-8222-222222222222',
  purpose: 'OWNERSHIP_REVIEW' as const,
};
export const reviewViewFixture = PracticeReviewReadRecordSchema.parse({
  version: 'v1', private: true, accessId: '33333333-3333-4333-8333-333333333333', isAuthorizationToken: false,
  assignment: {
    version: 'v1', id: reviewScope.assignmentId, submissionId: reviewScope.submissionId,
    evaluatorAccountId: 'evaluator', purpose: reviewScope.purpose,
    expiresAt: '2030-01-01T00:00:00.000Z', issuedAt: '2026-10-15T00:00:00.000Z',
    issuedByAccountId: 'issuer', reason: 'Synthetic scoped review', state: 'ISSUED', isAuthorizationToken: false,
  }, definition,
  submission: {
    version: 'v1', reference: { recordId: reviewScope.submissionId, revision: 1 },
    startId: '44444444-4444-4444-8444-444444444444', participantId: '55555555-5555-4555-8555-555555555555',
    skillId: definition.skillId, skillDomain: definition.skillDomain,
    definitionReference: definition.reference, rubricReference: definition.rubric.reference,
    state: 'SUBMITTED', submittedAt: '2026-10-15T00:00:00.000Z',
    answer: '\n  <script>private-answer-marker</script>\r\n', explanation: 'private-explanation-marker <img src=x>',
    toolsUsed: ['editor'], aiAssistanceUsed: true, assistanceDisclosure: 'private-disclosure-marker',
    ownership: 'UNCONFIRMED', persisted: true, verifiesSkill: false, isAuthorizationToken: false,
    createsPermissionGrant: false, consumesCapacity: false, createsFinancialObligation: false,
  },
});
