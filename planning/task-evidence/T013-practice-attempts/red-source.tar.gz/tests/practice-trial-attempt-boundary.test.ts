import { expect, it } from 'vitest';
import { EventEnvelopeSchema } from '../src/contracts/protocol';
it('permits only identifier references for a private start event', () => {
  const event = {
    eventId: 'e',
    type: 'skill.practice_trial_started.v1',
    aggregateId: 'trial',
    aggregateVersion: 1,
    occurredAt: '2026-10-15T00:00:00Z',
    actorId: 'actor',
    guildId: null,
    correlationId: 'r',
    payload: { practiceTrialStartId: 'start' },
  };
  expect(EventEnvelopeSchema.safeParse(event).success).toBe(true);
  for (const field of ['answers', 'submission', 'definition', 'assessedRank'])
    expect(
      EventEnvelopeSchema.safeParse({ ...event, payload: { ...event.payload, [field]: 'private' } })
        .success,
    ).toBe(false);
});
