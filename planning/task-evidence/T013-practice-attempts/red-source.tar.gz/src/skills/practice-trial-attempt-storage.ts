import { z } from 'zod';
import type { SkillTaxonomyActor } from './taxonomy-storage';
import type { CommandReceiptTransaction } from '../command-receipts';
export const PracticeTrialStartRecordSchema = z.never();
export type PracticeTrialStartRecord = Readonly<{
  id: string;
  participantId: string;
  attemptNumber: number;
  definition: { tools: unknown };
}>;
export async function startPracticeTrial(
  _tx: CommandReceiptTransaction,
  _command: {
    actor: SkillTaxonomyActor;
    input: unknown;
    idempotencyKey: string;
    requestId: string;
  },
  _options: { allowNewWrites: boolean },
): Promise<{ status: 'EXECUTED' | 'REPLAYED'; start: PracticeTrialStartRecord }> {
  throw Error('NOT_IMPLEMENTED');
}
export async function readPracticeTrialStart(
  _tx: CommandReceiptTransaction,
  _actor: SkillTaxonomyActor,
  _id: string,
): Promise<PracticeTrialStartRecord | null> {
  throw Error('NOT_IMPLEMENTED');
}
