import type { SkillTaxonomyActor } from '../skills/taxonomy-storage';
export function practiceTrialAttemptWriteConfiguration(): { writesAvailable: boolean; unavailableReason: 'DISABLED' | null } { throw Error('NOT_IMPLEMENTED'); }
export async function startPracticeTrialFromHost(_command: { actor: SkillTaxonomyActor; input: unknown; idempotencyKey: string; requestId: string }): Promise<unknown> { throw Error('NOT_IMPLEMENTED'); }
