// Test-first transport seam: business implementation follows recorded behavior RED.
export class PracticeOwnershipHttpError extends Error {
  constructor(readonly status: 401 | 403 | 429) { super('HTTP_AUTHORITY_DENIED'); }
}
export function createPracticeOwnershipHandlers(_host: unknown) {
  const unavailable = async (_request: Request, _params: unknown) => Response.json({}, { status: 503 });
  return { GET: unavailable, POST: unavailable };
}
